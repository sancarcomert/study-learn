import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app_colors.dart';
import 'app_text_styles.dart';
import 'tap_scale.dart';
import 'main_shell.dart';
import 'subject_provider.dart';
import 'task_provider.dart';
import 'stats_provider.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  String? _selectedSubject;
  final _customSubjectController = TextEditingController();

  static const List<String> _commonSubjects = [
    'Matematik',
    'Fizik',
    'Kimya',
    'Tarih',
    'İngilizce',
  ];

  @override
  void dispose() {
    _customSubjectController.dispose();
    super.dispose();
  }

  void _startWithSubject() {
    final subjectName = _selectedSubject ?? _customSubjectController.text.trim();
    if (subjectName.isEmpty) return;

    final colorValue = AppColors.subjectPalette.first.value;

    ref.read(subjectProvider.notifier).addSubject(subjectName, colorValue);

    final newSubjects = ref.read(subjectProvider);
    final createdSubject = newSubjects.firstWhere(
      (s) => s.name == subjectName,
      orElse: () => newSubjects.last,
    );

    ref.read(taskProvider.notifier).addTask(
          title: '📌 Örnek: Konu tekrarı yap',
          subjectId: createdSubject.id,
          dueDate: DateTime.now(),
          estimatedMinutes: 30,
        );

    _completeOnboarding();
  }

  void _skip() {
    _completeOnboarding();
  }

  void _completeOnboarding() {
    ref.read(statsProvider.notifier).markOnboardingCompleted();

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentSubject =
        _selectedSubject ?? _customSubjectController.text.trim();
    final hasSubject = currentSubject.isNotEmpty;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 24),

                Text(
                  'Study Planner\'a hoş geldin 👋',
                  style: AppTextStyles.heading1,
                ),

                const SizedBox(height: 8),

                Text(
                  'Sana özel bir başlangıç hazırlayalım.',
                  style: AppTextStyles.bodySecondary,
                ),

                const SizedBox(height: 32),

                Text(
                  'Şu an hangi derse çalışıyorsun?',
                  style: AppTextStyles.body,
                ),

                const SizedBox(height: 12),

                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _commonSubjects.map((subject) {
                    final isSelected = _selectedSubject == subject;
                    return TapScale(
                      onTap: () {
                        setState(() {
                          if (_selectedSubject == subject) {
                            _selectedSubject = null;
                          } else {
                            _selectedSubject = subject;
                            _customSubjectController.clear();
                          }
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.primary
                              : AppColors.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          subject,
                          style: TextStyle(
                            color: isSelected ? Colors.white : AppColors.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: _customSubjectController,
                  decoration: const InputDecoration(
                    hintText: 'Ya da kendi dersini yaz',
                  ),
                  onChanged: (value) {
                    setState(() {
                      if (value.isNotEmpty) {
                        _selectedSubject = null;
                      }
                    });
                  },
                ),

                const SizedBox(height: 32),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: hasSubject ? _startWithSubject : null,
                    child: const Text('Başlayalım'),
                  ),
                ),

                const SizedBox(height: 10),

                Center(
                  child: Text(
                    hasSubject
                        ? '$currentSubject dersiyle örnek bir görev oluşturacağız'
                        : 'Başlamak için en az 1 ders seçmelisin.',
                    textAlign: TextAlign.center,
                    style: AppTextStyles.caption,
                  ),
                ),

                const SizedBox(height: 8),

                Center(
                  child: TextButton(
                    onPressed: _skip,
                    child: Text(
                      'Şimdilik atla',
                      style: AppTextStyles.bodySecondary,
                    ),
                  ),
                ),

                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}