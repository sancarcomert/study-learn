// lib/widgets/week_strip.dart
import 'package:flutter/material.dart';
import '../task_model.dart';
import '../app_colors.dart';
import '../app_text_styles.dart';

class WeekStrip extends StatelessWidget {
  final List<TaskModel> allTasks;
  final Function(DateTime)? onDaySelected;

  const WeekStrip({
    super.key,
    required this.allTasks,
    this.onDaySelected,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final monday = now.subtract(Duration(days: now.weekday - 1));
    final dayLabels = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(7, (index) {
        final day = DateTime(monday.year, monday.month, monday.day + index);
        final isToday = day.year == now.year &&
            day.month == now.month &&
            day.day == now.day;

        final taskCount = allTasks
            .where((t) =>
                t.dueDate.year == day.year &&
                t.dueDate.month == day.month &&
                t.dueDate.day == day.day)
            .length;

        return GestureDetector(
          onTap: () {
            onDaySelected?.call(day);
          },
          child: Container(
            constraints: const BoxConstraints(minWidth: 44, minHeight: 44),
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(dayLabels[index], style: AppTextStyles.caption),
                const SizedBox(height: 8),
                Container(
                  width: 36,
                  height: 36,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color:
                        isToday ? const Color(0xFF14151A) : AppColors.surface,
                    shape: BoxShape.circle,
                    boxShadow: isToday ? null : AppColors.softShadow,
                  ),
                  child: Text(
                    '$taskCount',
                    style: AppTextStyles.body.copyWith(
                      color: isToday ? Colors.white : AppColors.textPrimary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}